# ProGuard rules for OpenClaw Android
# This file contains rules specifically for Termux components and third-party libraries

# Keep Termux emulator classes
-keep class com.termux.terminal.** { *; }
-keep class com.termux.view.** { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep WebView JavaScriptInterface methods
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Gson classes and annotations
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Keep data classes used with Gson
-keep class com.openclaw.android.BootstrapManager$SetupStatus { *; }
-keep class com.openclaw.android.BootstrapManager_Fixed$SetupStatus { *; }
-keep class com.openclaw.android.CommandRunner$CommandResult { *; }
-keep class com.openclaw.android.CommandRunner_Fixed$CommandResult { *; }
-keep class com.openclaw.android.UrlResolver$RemoteConfig { *; }
-keep class com.openclaw.android.UrlResolver$ComponentConfig { *; }
-keep class com.openclaw.android.UrlResolver$PlatformConfig { *; }
-keep class com.openclaw.android.UrlResolver_Fixed$RemoteConfig { *; }
-keep class com.openclaw.android.UrlResolver_Fixed$ComponentConfig { *; }
-keep class com.openclaw.android.UrlResolver_Fixed$PlatformConfig { *; }

# Keep coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Keep Android bindings
-keep class com.openclaw.android.databinding.** { *; }

# Preserve line numbers for debugging
-keepattributes SourceFile,LineNumberTable

# Optimize
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontpreverify
-verbose
