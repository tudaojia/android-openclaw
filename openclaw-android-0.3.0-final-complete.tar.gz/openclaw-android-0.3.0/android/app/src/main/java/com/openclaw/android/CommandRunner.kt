package com.openclaw.android

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Shell command execution via ProcessBuilder (§2.2.5).
 * Uses Termux bootstrap environment for all commands.
 *
 * FIXES v2.0:
 * - Fixed process cleanup on timeout
 * - Improved stream handling to prevent deadlocks
 * - Added better error handling
 * - Improved concurrent execution safety
 */
object CommandRunner {

    data class CommandResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    )

    /**
     * Run a command synchronously with timeout.
     * Returns stdout/stderr and exit code.
     * FIX: Improved process cleanup and stream handling
     */
    fun runSync(
        command: String,
        env: Map<String, String>,
        workDir: File,
        timeoutMs: Long = 5_000
    ): CommandResult {
        val shell = env["PREFIX"]?.let { "$it/bin/sh" } ?: "/system/bin/sh"
        var process: Process? = null

        return try {
            val pb = ProcessBuilder(shell, "-c", command)
            pb.environment().clear()
            pb.environment().putAll(env)
            pb.directory(workDir)
            pb.redirectErrorStream(false)

            process = pb.start()

            // FIX: Read streams concurrently to prevent deadlocks
            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            val stdoutThread = Thread {
                try {
                    process.inputStream.bufferedReader().use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            stdoutBuilder.appendLine(line)
                        }
                    }
                } catch (e: Exception) {
                    // Thread interrupted during shutdown
                }
            }

            val stderrThread = Thread {
                try {
                    process.errorStream.bufferedReader().use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            stderrBuilder.appendLine(line)
                        }
                    }
                } catch (e: Exception) {
                    // Thread interrupted during shutdown
                }
            }

            stdoutThread.start()
            stderrThread.start()

            val exited = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)

            // Wait for stream threads to finish with timeout
            stdoutThread.join(1000)
            stderrThread.join(1000)

            if (!exited) {
                // FIX: Ensure process is properly destroyed
                process.destroyForcibly()
                CommandResult(
                    -1,
                    stdoutBuilder.toString(),
                    "Command timed out after ${timeoutMs}ms\n${stderrBuilder.toString()}"
                )
            } else {
                CommandResult(
                    process.exitValue(),
                    stdoutBuilder.toString(),
                    stderrBuilder.toString()
                )
            }
        } catch (e: InterruptedException) {
            // FIX: Clean up on interruption
            process?.destroyForcibly()
            CommandResult(-1, "", "Command interrupted: ${e.message}")
        } catch (e: Exception) {
            process?.destroyForcibly()
            CommandResult(-1, "", "Command failed: ${e.message ?: "Unknown error"}")
        }
    }

    /**
     * Run a command asynchronously, streaming output line-by-line via callback.
     * FIX: Improved error handling and process cleanup
     */
    suspend fun runStreaming(
        command: String,
        env: Map<String, String>,
        workDir: File,
        onOutput: (String) -> Unit,
        timeoutMs: Long = 30_000  // FIX: Increased default timeout
    ) = withContext(Dispatchers.IO) {
        val shell = env["PREFIX"]?.let { "$it/bin/sh" } ?: "/system/bin/sh"
        var process: Process? = null

        try {
            val pb = ProcessBuilder(shell, "-c", command)
            pb.environment().clear()
            pb.environment().putAll(env)
            pb.directory(workDir)
            pb.redirectErrorStream(true)

            process = pb.start()

            // Use timeout for the entire process
            val startTime = System.currentTimeMillis()

            process.inputStream.bufferedReader().use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    // Check timeout
                    if (System.currentTimeMillis() - startTime > timeoutMs) {
                        onOutput("Error: Command timeout after ${timeoutMs}ms")
                        break
                    }
                    onOutput(line)
                }
            }

            val exitCode = if (!process.isAlive) {
                process.exitValue()
            } else {
                // FIX: Clean up if process still running
                process.destroyForcibly()
                -1
            }

            if (exitCode != 0) {
                onOutput("Command exited with code: $exitCode")
            }
        } catch (e: Exception) {
            onOutput("Error: ${e.message}")
            // FIX: Ensure cleanup on error
            process?.destroyForcibly()
        }
    }

    /**
     * NEW: Run command with custom timeout and callback for both stdout and stderr
     */
    suspend fun runStreamingWithStderr(
        command: String,
        env: Map<String, String>,
        workDir: File,
        onStdout: (String) -> Unit,
        onStderr: (String) -> Unit,
        timeoutMs: Long = 30_000
    ) = withContext(Dispatchers.IO) {
        val shell = env["PREFIX"]?.let { "$it/bin/sh" } ?: "/system/bin/sh"
        var process: Process? = null

        try {
            val pb = ProcessBuilder(shell, "-c", command)
            pb.environment().clear()
            pb.environment().putAll(env)
            pb.directory(workDir)
            pb.redirectErrorStream(false)  // Separate stdout and stderr

            process = pb.start()

            val startTime = System.currentTimeMillis()

            // Read stdout
            val stdoutThread = Thread {
                try {
                    process.inputStream.bufferedReader().use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            if (System.currentTimeMillis() - startTime > timeoutMs) break
                            onStdout(line)
                        }
                    }
                } catch (e: Exception) {
                    // Ignore
                }
            }

            // Read stderr
            val stderrThread = Thread {
                try {
                    process.errorStream.bufferedReader().use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            if (System.currentTimeMillis() - startTime > timeoutMs) break
                            onStderr(line)
                        }
                    }
                } catch (e: Exception) {
                    // Ignore
                }
            }

            stdoutThread.start()
            stderrThread.start()

            // Wait for process completion or timeout
            val exited = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)

            stdoutThread.join(500)
            stderrThread.join(500)

            if (!exited) {
                process.destroyForcibly()
                onStderr("Command timed out after ${timeoutMs}ms")
            }

            val exitCode = if (exited && !process.isAlive) {
                process.exitValue()
            } else {
                -1
            }

            if (exitCode != 0) {
                onStderr("Command exited with code: $exitCode")
            }
        } catch (e: Exception) {
            onStderr("Error: ${e.message}")
            process?.destroyForcibly()
        }
    }
}
