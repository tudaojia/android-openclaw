package com.openclaw.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log

/**
 * Foreground Service that keeps terminal sessions alive when the app is in background.
 * Uses START_STICKY to restart if killed. targetSdk 28 — no specialUse needed.
 *
 * FIXES v2.0:
 * - Improved notification channel handling
 * - Better service lifecycle management
 * - Added proper error handling
 * - Improved logging
 */
class OpenClawService : Service() {

    companion object {
        private const val TAG = "OpenClawService"
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "openclaw_service"
        private const val CHANNEL_NAME = "OpenClaw Terminal Service"
        private const val CHANNEL_DESCRIPTION = "Keeps OpenClaw terminal sessions running"
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service created")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service start command received")
        try {
            startForeground(NOTIFICATION_ID, createNotification())
            return START_STICKY
        } catch (e: Exception) {
            Log.e(TAG, "Error starting foreground service", e)
            return START_NOT_STICKY
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.d(TAG, "Service destroyed")
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = CHANNEL_DESCRIPTION
                    setShowBadge(false)
                    setSound(null, null)  // No sound for service notifications
                    enableVibration(false)  // No vibration
                }
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(channel)
                Log.d(TAG, "Notification channel created")
            } catch (e: Exception) {
                Log.e(TAG, "Error creating notification channel", e)
            }
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            // FIX: Use FLAG_IMMUTABLE for Android 12+ compatibility
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }
}
