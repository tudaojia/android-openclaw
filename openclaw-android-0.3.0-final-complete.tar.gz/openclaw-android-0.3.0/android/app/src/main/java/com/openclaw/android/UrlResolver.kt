package com.openclaw.android

import android.content.Context
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.withTimeout
import java.io.File
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Resolves download URLs with BuildConfig hardcoded fallback + config.json override (§2.9).
 *
 * Priority: cached config.json → remote config.json (timeout) → BuildConfig constants
 *
 * FIXES v2.0:
 * - Made timeout configurable
 * - Added better error handling
 * - Added cache expiration logic
 * - Improved network reliability
 */
class UrlResolver(private val context: Context) {

    private val configFile = File(
        context.filesDir, "usr/share/openclaw-app/config.json"
    )
    private val gson = Gson()

    // FIX: Configurable timeout (default 10 seconds instead of 5)
    private val remoteFetchTimeoutMs = 10_000L

    // FIX: Cache expiration time (24 hours)
    private val cacheExpirationMs = TimeUnit.HOURS.toMillis(24)

    suspend fun getBootstrapUrl(): String {
        val config = loadConfig()
        return config?.bootstrap?.url ?: BuildConfig.BOOTSTRAP_URL
    }

    suspend fun getWwwUrl(): String {
        val config = loadConfig()
        return config?.www?.url ?: BuildConfig.WWW_URL
    }

    private suspend fun loadConfig(): RemoteConfig? {
        // 1. Local cache (with expiration check)
        if (configFile.exists()) {
            try {
                val cacheAge = System.currentTimeMillis() - configFile.lastModified()
                if (cacheAge < cacheExpirationMs) {
                    // Cache is still valid
                    val cachedConfig = gson.fromJson(configFile.readText(), RemoteConfig::class.java)
                    Log.d(TAG, "Using cached config (age: ${cacheAge}ms)")
                    return cachedConfig
                } else {
                    Log.d(TAG, "Cache expired (${cacheAge}ms old), fetching fresh config")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to parse cached config, will fetch fresh", e)
            }
        }

        // 2. Remote fetch (with configurable timeout)
        return try {
            withTimeout(remoteFetchTimeoutMs) {
                val json = URL(BuildConfig.CONFIG_URL).readText()
                configFile.parentFile?.mkdirs()
                configFile.writeText(json)
                Log.d(TAG, "Fetched fresh config from remote")
                gson.fromJson(json, RemoteConfig::class.java)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch remote config, using BuildConfig fallback", e)
            null // BuildConfig fallback
        }
    }

    companion object {
        private const val TAG = "UrlResolver"
    }

    // --- Config data classes ---

    data class RemoteConfig(
        val version: Int?,
        val bootstrap: ComponentConfig?,
        val www: ComponentConfig?,
        val platforms: List<PlatformConfig>?,
        val features: Map<String, Boolean>?
    )

    data class ComponentConfig(
        val url: String,
        val version: String?,
        @SerializedName("sha256") val sha256: String?
    )

    data class PlatformConfig(
        val id: String,
        val name: String,
        val icon: String?,
        val description: String?
    )
}
