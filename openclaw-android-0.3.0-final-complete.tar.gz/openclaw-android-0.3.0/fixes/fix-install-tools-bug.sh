#!/usr/bin/env bash
# =============================================================================
# fix-install-tools-bug.sh - 修复 npm 工具安装失败但标记为成功的 bug
#
# 问题根源：
# install.sh 和 install-tools.sh 使用了 "|| true" 模式，导致 npm 安装失败时
# 脚本继续执行并显示 "[OK] installed"，误导用户以为安装成功。
#
# 修复内容：
# 1. 检查 npm 安装错误日志
# 2. 修复 DNS 解析问题（如果适用）
# 3. 提供备用安装源
# 4. 修复脚本错误处理逻辑
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

PROJECT_DIR="$HOME/.openclaw-android"
NPM_LOG_DIR="$HOME/.npm/_logs"

echo ""
echo -e "${BOLD}========================================${NC}"
echo -e "${BOLD}  OpenClaw Android - 安装工具修复工具${NC}"
echo -e "${BOLD}========================================${NC}"
echo ""

# ============================================================================
# 第一步：诊断安装失败原因
# ============================================================================
echo -e "${BOLD}[步骤 1/5] 诊断安装失败原因${NC}"
echo ""

# 检查 npm 错误日志
echo "检查 npm 错误日志..."
if [ -d "$NPM_LOG_DIR" ]; then
    recent_logs=$(ls -t "$NPM_LOG_DIR"/*.log 2>/dev/null | head -5)
    if [ -n "$recent_logs" ]; then
        echo -e "${YELLOW}发现最近的 npm 错误日志：${NC}"
        for log in $recent_logs; do
            echo ""
            echo -e "${BLUE}日志: $(basename "$log")${NC}"
            echo "---"
            # 提取关键错误信息
            grep -i "error\|failed\|EAI_AGAIN\|ENOTFOUND" "$log" | tail -5 || true
        done
    else
        echo -e "${GREEN}✓${NC} 没有发现 npm 错误日志"
    fi
else
    echo -e "${YELLOW}⚠${NC} npm 日志目录不存在"
fi

# 检查网络连接
echo ""
echo "检查网络连接..."
check_dns_resolution() {
    local host=$1
    if timeout 5 nslookup "$host" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} $host DNS 解析正常"
        return 0
    else
        echo -e "  ${RED}✗${NC} $host DNS 解析失败"
        return 1
    fi
}

dns_ok=true
check_dns_resolution "registry.npmjs.org" || dns_ok=false
check_dns_resolution "github.com" || dns_ok=false

# 检查 npm 配置
echo ""
echo "当前 npm 配置："
npm config get registry 2>/dev/null || echo "  未配置"

# 检查 Node.js 版本
echo ""
echo "Node.js 版本：$(node --version 2>/dev/null || echo "未安装")"
echo "npm 版本：$(npm --version 2>/dev/null || echo "未安装")"

# ============================================================================
# 第二步：检查哪些工具实际安装失败
# ============================================================================
echo ""
echo -e "${BOLD}[步骤 2/5] 检查工具安装状态${NC}"
echo ""

declare -A TOOLS
TOOLS=(
    ["code-server"]="code-server"
    ["Claude Code"]="claude"
    ["Gemini CLI"]="gemini"
    ["Codex CLI"]="codex"
    ["OpenCode"]="opencode"
)

failed_tools=()
installed_tools=()

for tool_name in "${!TOOLS[@]}"; do
    cmd=${TOOLS[$tool_name]}
    if command -v "$cmd" &>/dev/null; then
        echo -e "  ${GREEN}[已安装]${NC} $tool_name"
        installed_tools+=("$tool_name")
    else
        echo -e "  ${RED}[未安装]${NC} $tool_name"
        failed_tools+=("$tool_name")
    fi
done

if [ ${#failed_tools[@]} -eq 0 ]; then
    echo ""
    echo -e "${GREEN}所有工具都已正确安装！${NC}"
    exit 0
fi

echo ""
echo -e "${YELLOW}发现 ${#failed_tools[@]} 个工具安装失败：${NC}"
for tool in "${failed_tools[@]}"; do
    echo "  - $tool"
done

# ============================================================================
# 第三步：修复 DNS 和网络问题
# ============================================================================
echo ""
echo -e "${BOLD}[步骤 3/5] 修复 DNS 和网络配置${NC}"
echo ""

if [ "$dns_ok" = false ]; then
    echo -e "${YELLOW}检测到 DNS 解析问题，尝试修复...${NC}"

    # 方案 1: 使用公共 DNS
    echo ""
    echo "方案 1: 配置使用公共 DNS"
    echo "  当前 DNS 配置："
    getprop | grep dns | grep -v "dns\]" || echo "    未找到 DNS 配置"

    echo ""
    echo "  建议修改 DNS 为以下地址（需要在系统 WiFi 设置中手动配置）："
    echo "    Google DNS: 8.8.8.8, 8.8.4.4"
    echo "    Cloudflare: 1.1.1.1, 1.0.0.1"

    # 方案 2: 配置 npm 使用镜像
    echo ""
    echo "方案 2: 配置 npm 使用国内镜像（推荐）"

    echo ""
    read -rp "是否配置 npm 使用淘宝镜像？[Y/n] " use_mirror
    if [[ ! "${use_mirror:-}" =~ ^[Nn]$ ]]; then
        npm config set registry https://registry.npmmirror.com
        echo -e "  ${GREEN}✓${NC} npm 镜像已配置为淘宝镜像"

        # 同时配置 GitHub 镜像（用于下载 code-server）
        echo ""
        echo "配置 GitHub 加速..."
        echo "  添加以下内容到 ~/.bashrc 或 ~/.npmrc："
        echo "    export ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/"
        echo "    export S3_ENDPOINT=https://npmmirror.com/mirrors/electron/"
        echo "    export GH_PROXY=https://mirror.ghproxy.com/"

        # 自动添加到环境变量
        if ! grep -q "ELECTRON_MIRROR" ~/.bashrc; then
            cat >> ~/.bashrc << 'EOF'

# npm 和 GitHub 加速配置
export ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/
export S3_ENDPOINT=https://npmmirror.com/mirrors/electron/
export GH_PROXY=https://mirror.ghproxy.com/
EOF
            echo -e "  ${GREEN}✓${NC} 已添加到 ~/.bashrc"
        fi
    fi
else
    echo -e "${GREEN}✓${NC} DNS 解析正常"
fi

# ============================================================================
# 第四步：重新安装失败的工具
# ============================================================================
echo ""
echo -e "${BOLD}[步骤 4/5] 重新安装失败的工具${NC}"
echo ""

# 创建改进的安装函数
install_npm_tool_safely() {
    local tool_name="$1"
    local package_name="$2"

    echo ""
    echo "正在安装 $tool_name..."
    echo "  包名: $package_name"

    # 使用 verbose 模式以获取更多错误信息
    if npm install -g "$package_name" --verbose 2>&1 | tee /tmp/npm-install-${package_name}.log; then
        echo -e "  ${GREEN}✓${NC} $tool_name 安装成功"
        return 0
    else
        echo -e "  ${RED}✗${NC} $tool_name 安装失败"
        echo ""
        echo "  错误详情："
        tail -20 /tmp/npm-install-${package_name}.log | sed 's/^/    /'

        # 尝试备用方案
        echo ""
        echo "  尝试备用方案：使用 --force 标志"
        if npm install -g "$package_name" --force 2>&1 | tee /tmp/npm-install-${package_name}-force.log; then
            echo -e "  ${GREEN}✓${NC} $tool_name 使用 --force 安装成功"
            return 0
        else
            echo -e "  ${RED}✗${NC} 备用方案也失败"
            return 1
        fi
    fi
}

# 重新安装失败的 npm 工具
reinstall_results=()

if [[ " ${failed_tools[*]} " =~ " Claude Code " ]]; then
    if install_npm_tool_safely "Claude Code" "@anthropic-ai/claude-code"; then
        reinstall_results+=("Claude Code:成功")
    else
        reinstall_results+=("Claude Code:失败")
    fi
fi

if [[ " ${failed_tools[*]} " =~ " Gemini CLI " ]]; then
    if install_npm_tool_safely "Gemini CLI" "@google/gemini-cli"; then
        reinstall_results+=("Gemini CLI:成功")
    else
        reinstall_results+=("Gemini CLI:失败")
    fi
fi

if [[ " ${failed_tools[*]} " =~ " Codex CLI " ]]; then
    if install_npm_tool_safely "Codex CLI" "@openai/codex"; then
        reinstall_results+=("Codex CLI:成功")
    else
        reinstall_results+=("Codex CLI:失败")
    fi
fi

# code-server 需要特殊处理
if [[ " ${failed_tools[*]} " =~ " code-server " ]]; then
    echo ""
    echo "正在安装 code-server..."

    # 下载安装脚本
    mkdir -p "$PREFIX/tmp"
    RELEASE_TMP=$(mktemp -d "$PREFIX/tmp/oa-install.XXXXXX")
    trap 'rm -rf "$RELEASE_TMP"' EXIT

    if curl -sfL "https://github.com/AidanPark/openclaw-android/archive/refs/heads/main.tar.gz" | \
       tar xz -C "$RELEASE_TMP" --strip-components=1; then

        mkdir -p "$PROJECT_DIR/patches"
        cp "$RELEASE_TMP/patches/argon2-stub.js" "$PROJECT_DIR/patches/argon2-stub.js"

        if bash "$RELEASE_TMP/scripts/install-code-server.sh" install; then
            echo -e "  ${GREEN}✓${NC} code-server 安装成功"
            reinstall_results+=("code-server:成功")
        else
            echo -e "  ${RED}✗${NC} code-server 安装失败"
            reinstall_results+=("code-server:失败")
        fi
    else
        echo -e "  ${RED}✗${NC} 无法下载安装脚本"
        reinstall_results+=("code-server:失败")
    fi
fi

# ============================================================================
# 第五步：验证修复结果
# ============================================================================
echo ""
echo -e "${BOLD}[步骤 5/5] 验证修复结果${NC}"
echo ""

echo "重新安装结果："
for result in "${reinstall_results[@]}"; do
    tool="${result%%:*}"
    status="${result##*:}"

    if [ "$status" = "成功" ]; then
        echo -e "  ${GREEN}✓${NC} $tool: 安装成功"
    else
        echo -e "  ${RED}✗${NC} $tool: 安装失败"
    fi
done

echo ""
echo "最终安装状态："
for tool_name in "${!TOOLS[@]}"; do
    cmd=${TOOLS[$tool_name]}
    if command -v "$cmd" &>/dev/null; then
        echo -e "  ${GREEN}[已安装]${NC} $tool_name"
    else
        echo -e "  ${RED}[未安装]${NC} $tool_name"
    fi
done

# ============================================================================
# 生成修复报告
# ============================================================================
echo ""
echo -e "${BOLD}========================================${NC}"
echo ""

# 统计结果
total_failed=${#failed_tools[@]}
success_count=0
for result in "${reinstall_results[@]}"; do
    if [[ "$result" == *:成功 ]]; then
        ((success_count++))
    fi
done

if [ $success_count -eq $total_failed ]; then
    echo -e "${GREEN}${BOLD}所有工具已成功修复！${NC}"
    echo ""
    echo "可以运行以下命令验证："
    echo "  oa --status"
else
    echo -e "${YELLOW}部分工具修复失败 (${success_count}/${total_failed})${NC}"
    echo ""
    echo "建议操作："
    echo "  1. 检查网络连接"
    echo "  2. 尝试切换网络（Wi-Fi/4G）"
    echo "  3. 配置 VPN 或代理"
    echo "  4. 手动安装失败的包"
    echo ""
    echo "手动安装命令："
    echo "  npm install -g @anthropic-ai/claude-code"
    echo "  npm install -g @google/gemini-cli"
    echo "  npm install -g @openai/codex"
fi

echo ""
echo "详细日志已保存到："
echo "  $HOME/.npm/_logs/"
echo "  /tmp/npm-install-*.log"

echo ""
