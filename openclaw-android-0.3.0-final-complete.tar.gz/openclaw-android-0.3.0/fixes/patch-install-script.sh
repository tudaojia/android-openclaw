#!/usr/bin/env bash
# =============================================================================
# patch-install-script.sh - 原地修补 OpenClaw Android 安装脚本
#
# 功能：直接修改已安装的 install.sh 和 install-tools.sh，修复 bug
#      无需重新下载整个项目
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

PROJECT_DIR="$HOME/.openclaw-android"
BACKUP_DIR="$PROJECT_DIR/backups/$(date +%Y%m%d_%H%M%S)"

echo ""
echo -e "${BOLD}========================================${NC}"
echo -e "${BOLD}  OpenClaw Android - 脚本修补工具${NC}"
echo -e "${BOLD}========================================${NC}"
echo ""

# 检查是否存在安装目录
if [ ! -d "$PROJECT_DIR" ]; then
    echo -e "${RED}[FAIL]${NC} OpenClaw Android 未安装"
    echo "  预期路径: $PROJECT_DIR"
    exit 1
fi

# 创建备份目录
mkdir -p "$BACKUP_DIR"
echo -e "${GREEN}✓${NC} 备份目录: $BACKUP_DIR"

# ============================================================================
# 修补 install.sh 中的 npm 安装命令
# ============================================================================
echo ""
echo -e "${BOLD}[1/3] 修补 install.sh${NC}"

INSTALL_SH="$PROJECT_DIR/scripts/install.sh"

if [ ! -f "$INSTALL_SH" ]; then
    echo -e "${YELLOW}⚠${NC} install.sh 不存在于预期位置"
    echo "  搜索中..."
    INSTALL_SH=$(find "$PROJECT_DIR" -name "install.sh" -type f 2>/dev/null | head -1)

    if [ -z "$INSTALL_SH" ]; then
        echo -e "${RED}[FAIL]${NC} 无法找到 install.sh"
        exit 1
    else
        echo -e "${GREEN}✓${NC} 找到: $INSTALL_SH"
    fi
fi

# 备份原始文件
cp "$INSTALL_SH" "$BACKUP_DIR/install.sh"
echo "  已备份原始文件"

# 修补 npm 安装命令
echo "  修补 npm 安装错误处理..."

# 检查是否需要修补
if grep -q 'npm install.*|| true' "$INSTALL_SH"; then
    # 创建临时文件
    TMP_FILE=$(mktemp)

    # 替换有问题的 npm 安装行
    sed -E 's|\[ "\$INSTALL_CLAUDE_CODE" = true \] && npm install -g @anthropic-ai/claude-code \|\| true|[ "\$INSTALL_CLAUDE_CODE" = true ] \&\& if npm install -g @anthropic-ai/claude-code; then echo -e "\${GREEN}[OK]\${NC}   Claude Code installed"; else echo -e "\${RED}[FAIL]\${NC}   Claude Code installation failed"; FAILED_TOOLS+=("Claude Code"); INSTALL_FAILED=1; fi|' \
        "$INSTALL_SH" > "$TMP_FILE"

    sed -E 's|\[ "\$INSTALL_GEMINI_CLI" = true \] && npm install -g @google/gemini-cli \|\| true|[ "\$INSTALL_GEMINI_CLI" = true ] \&\& if npm install -g @google/gemini-cli; then echo -e "\${GREEN}[OK]\${NC}   Gemini CLI installed"; else echo -e "\${RED}[FAIL]\${NC}   Gemini CLI installation failed"; FAILED_TOOLS+=("Gemini CLI"); INSTALL_FAILED=1; fi|' \
        "$TMP_FILE" > "$TMP_FILE.2"

    sed -E 's|\[ "\$INSTALL_CODEX_CLI" = true \] && npm install -g @openai/codex \|\| true|[ "\$INSTALL_CODEX_CLI" = true ] \&\& if npm install -g @openai/codex; then echo -e "\${GREEN}[OK]\${NC}   Codex CLI installed"; else echo -e "\${RED}[FAIL]\${NC}   Codex CLI installation failed"; FAILED_TOOLS+=("Codex CLI"); INSTALL_FAILED=1; fi|' \
        "$TMP_FILE.2" > "$INSTALL_SH"

    # 清理临时文件
    rm -f "$TMP_FILE" "$TMP_FILE.2"

    echo -e "  ${GREEN}✓${NC} install.sh 已修补"
else
    echo -e "  ${YELLOW}⚠${NC} install.sh 可能已经修补过或版本不同"
fi

# 添加失败计数变量（如果不存在）
if ! grep -q 'INSTALL_FAILED=0' "$INSTALL_SH"; then
    echo "  添加失败计数变量..."
    sed -i '/^declare -A TOOL_STATUS/a INSTALL_FAILED=0\nFAILED_TOOLS=()' "$INSTALL_SH"
fi

# ============================================================================
# 修补 install-tools.sh
# ============================================================================
echo ""
echo -e "${BOLD}[2/3] 修补 install-tools.sh${NC}"

INSTALL_TOOLS_SH="$PREFIX/bin/oa"  # install-tools 通常被安装为 oa 命令

# 查找 install-tools.sh 的实际位置
if grep -q "install-tools.sh" "$INSTALL_TOOLS_SH" 2>/dev/null; then
    echo "  install-tools.sh 已集成到 oa 命令中"
    INSTALL_TOOLS_SH="$INSTALL_TOOLS_SH"
elif [ -f "$PROJECT_DIR/install-tools.sh" ]; then
    INSTALL_TOOLS_SH="$PROJECT_DIR/install-tools.sh"
else
    # 搜索
    INSTALL_TOOLS_SH=$(find "$PROJECT_DIR" -name "install-tools.sh" -type f 2>/dev/null | head -1)
    if [ -z "$INSTALL_TOOLS_SH" ]; then
        echo -e "${YELLOW}⚠${NC} 无法找到 install-tools.sh，跳过"
        INSTALL_TOOLS_SH=""
    else
        echo -e "  ${GREEN}✓${NC} 找到: $INSTALL_TOOLS_SH"
    fi
fi

if [ -n "$INSTALL_TOOLS_SH" ] && [ -f "$INSTALL_TOOLS_SH" ]; then
    # 备份
    cp "$INSTALL_TOOLS_SH" "$BACKUP_DIR/$(basename "$INSTALL_TOOLS_SH")"
    echo "  已备份原始文件"

    # 修补
    echo "  修补 npm 安装错误处理..."

    TMP_FILE=$(mktemp)

    # 替换有问题的行
    sed -E 's|\[ "\$INSTALL_CLAUDE_CODE" = true \] && echo "Installing Claude Code\.\.\." && npm install -g @anthropic-ai/claude-code && echo -e "\${GREEN}\[OK\]\${NC}   Claude Code installed" \|\| true|if [ "\$INSTALL_CLAUDE_CODE" = true ]; then echo "Installing Claude Code..."; if npm install -g @anthropic-ai/claude-code; then echo -e "\${GREEN}[OK]\${NC}   Claude Code installed"; else echo -e "\${RED}[FAIL]\${NC}   Claude Code installation failed"; INSTALL_FAILED=1; FAILED_TOOLS+=("Claude Code"); fi; fi|' \
        "$INSTALL_TOOLS_SH" > "$TMP_FILE"

    sed -E 's|\[ "\$INSTALL_GEMINI_CLI" = true \] && echo "Installing Gemini CLI\.\.\." && npm install -g @google/gemini-cli && echo -e "\${GREEN}\[OK\]\${NC}   Gemini CLI installed" \|\| true|if [ "\$INSTALL_GEMINI_CLI" = true ]; then echo "Installing Gemini CLI..."; if npm install -g @google/gemini-cli; then echo -e "\${GREEN}[OK]\${NC}   Gemini CLI installed"; else echo -e "\${RED}[FAIL]\${NC}   Gemini CLI installation failed"; INSTALL_FAILED=1; FAILED_TOOLS+=("Gemini CLI"); fi; fi|' \
        "$TMP_FILE" > "$TMP_FILE.2"

    sed -E 's|\[ "\$INSTALL_CODEX_CLI" = true \] && echo "Installing Codex CLI\.\.\." && npm install -g @openai/codex && echo -e "\${GREEN}\[OK\]\${NC}   Codex CLI installed" \|\| true|if [ "\$INSTALL_CODEX_CLI" = true ]; then echo "Installing Codex CLI..."; if npm install -g @openai/codex; then echo -e "\${GREEN}[OK]\${NC}   Codex CLI installed"; else echo -e "\${RED}[FAIL]\${NC}   Codex CLI installation failed"; INSTALL_FAILED=1; FAILED_TOOLS+=("Codex CLI"); fi; fi|' \
        "$TMP_FILE.2" > "$INSTALL_TOOLS_SH"

    rm -f "$TMP_FILE" "$TMP_FILE.2"

    echo -e "  ${GREEN}✓${NC} install-tools.sh 已修补"
fi

# ============================================================================
# 创建独立的修复脚本到项目目录
# ============================================================================
echo ""
echo -e "${BOLD}[3/3] 创建修复工具${NC}"

# 复制修复脚本到项目目录
FIX_SCRIPT="$PROJECT_DIR/fix-install-tools-bug.sh"

if [ -f "fix-install-tools-bug.sh" ]; then
    cp fix-install-tools-bug.sh "$FIX_SCRIPT"
    chmod +x "$FIX_SCRIPT"
    echo -e "  ${GREEN}✓${NC} 已创建修复工具: $FIX_SCRIPT"
else
    echo -e "  ${YELLOW}⚠${NC} fix-install-tools-bug.sh 不在当前目录"
fi

# ============================================================================
# 修补完成
# ============================================================================
echo ""
echo -e "${BOLD}========================================${NC}"
echo -e "${GREEN}${BOLD}✓ 修补完成！${NC}"
echo -e "${BOLD}========================================${NC}"
echo ""

echo "修补内容："
echo "  1. 修复 install.sh 中的 npm 错误处理"
echo "  2. 修复 install-tools.sh 中的 npm 错误处理"
echo "  3. 安装修复工具到项目目录"
echo ""

echo "备份位置："
echo "  $BACKUP_DIR"
echo ""

echo "下一步操作："
echo ""
echo "方案 1: 运行修复工具（推荐）"
echo "  bash $FIX_SCRIPT"
echo ""

echo "方案 2: 重新安装失败的工具"
echo "  oa --install"
echo ""

echo "方案 3: 手动安装"
echo "  npm install -g @anthropic-ai/claude-code"
echo "  npm install -g @google/gemini-cli"
echo "  npm install -g @openai/codex"
echo ""

echo "验证安装："
echo "  oa --status"
echo ""

# 检查是否需要配置 npm 镜像
echo -e "${YELLOW}💡 提示：${NC}"
echo "  如果持续遇到网络问题，建议配置 npm 使用国内镜像："
echo "  npm config set registry https://registry.npmmirror.com"
echo ""

read -rp "是否现在运行修复工具？[Y/n] " run_fix
if [[ ! "${run_fix:-}" =~ ^[Nn]$ ]]; then
    echo ""
    echo "运行修复工具..."
    bash "$FIX_SCRIPT"
else
    echo ""
    echo "您可以稍后手动运行: bash $FIX_SCRIPT"
fi
